<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('reports.index')); ?>">Reports</a></li>
    <li class="breadcrumb-item active" aria-current="page">Worker Report</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .worker-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; padding: 25px; color: #fff; }
        .worker-header .avatar { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 4px solid rgba(255,255,255,0.3); }
        .worker-header .name { font-size: 1.5rem; font-weight: 700; }
        .worker-header .id { opacity: 0.8; }
        .stat-card { background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 3px 15px rgba(0,0,0,0.08); text-align: center; height: 100%; }
        .stat-card .value { font-size: 1.8rem; font-weight: 700; color: #667eea; }
        .stat-card .label { font-size: 0.8rem; color: #888; text-transform: uppercase; }
        .stat-card.success .value { color: #2ecc71; }
        .stat-card.warning .value { color: #e74c3c; }
        .daily-chart { display: flex; align-items: flex-end; height: 150px; gap: 3px; overflow-x: auto; padding-bottom: 25px; }
        .daily-chart .bar-item { min-width: 25px; text-align: center; }
        .daily-chart .bar { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 3px 3px 0 0; width: 20px; margin: 0 auto; }
        .daily-chart .bar-label { font-size: 0.6rem; color: #888; margin-top: 5px; transform: rotate(-45deg); white-space: nowrap; }
        .log-row { background: #f8f9fa; border-radius: 8px; padding: 12px 15px; margin-bottom: 8px; }
        .log-row:hover { background: #e9ecef; }
        .log-row .time { font-family: monospace; background: #fff; padding: 2px 8px; border-radius: 4px; font-size: 0.8rem; }
        .log-row .table-badge { font-weight: 600; color: #667eea; }
        .log-row .count { font-weight: 700; }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row layout-top-spacing">
        
        <div class="col-12 layout-spacing">
            <div class="worker-header">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <img src="<?php echo e($worker->photo ? asset('storage/'.$worker->photo) : asset('assets/src/assets/img/profile-30.png')); ?>"
                             class="avatar" alt="<?php echo e($worker->name); ?>">
                    </div>
                    <div class="col">
                        <div class="name"><?php echo e($worker->name); ?></div>
                        <div class="id"><?php echo e($worker->worker_id); ?></div>
                        <div class="mt-2">
                            <span class="badge bg-light text-dark me-1"><?php echo e($worker->skill_level ?? 'General'); ?></span>
                            <span class="badge bg-light text-dark"><?php echo e($worker->department ?? 'Production'); ?></span>
                        </div>
                    </div>
                    <div class="col-auto">
                        <a href="<?php echo e(route('workers.show', $worker)); ?>" class="btn btn-light">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user me-1"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                            View Profile
                        </a>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-12 layout-spacing">
            <div class="widget-content widget-content-area br-8">
                <form action="<?php echo e(route('reports.worker', $worker)); ?>" method="GET" class="row align-items-end g-3">
                    <div class="col-md-4">
                        <label class="form-label">Start Date</label>
                        <input type="date" name="start_date" class="form-control" value="<?php echo e($startDate); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">End Date</label>
                        <input type="date" name="end_date" class="form-control" value="<?php echo e($endDate); ?>">
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-primary w-100">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-filter me-1"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
                            Apply Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>

        
        <div class="col-xl-3 col-lg-6 col-md-6 layout-spacing">
            <div class="stat-card">
                <div class="value"><?php echo e(number_format($summary['total_production'])); ?></div>
                <div class="label">Total Production</div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 layout-spacing">
            <div class="stat-card">
                <div class="value"><?php echo e(number_format($summary['avg_daily'])); ?></div>
                <div class="label">Avg Daily</div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 layout-spacing">
            <div class="stat-card success">
                <div class="value"><?php echo e($summary['green_lights']); ?></div>
                <div class="label">Green Lights</div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 layout-spacing">
            <div class="stat-card warning">
                <div class="value"><?php echo e($summary['red_alerts']); ?></div>
                <div class="label">Red Alerts</div>
            </div>
        </div>

        
        <div class="col-xl-8 col-lg-7 layout-spacing">
            <div class="widget-content widget-content-area br-8 h-100">
                <h6 class="mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-activity me-2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                    Daily Production
                </h6>

                <?php
                    $maxDaily = $dailyProduction->max('total') ?: 1;
                ?>

                <div class="daily-chart">
                    <?php $__empty_1 = true; $__currentLoopData = $dailyProduction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="bar-item">
                            <div class="bar" style="height: <?php echo e(($day->total / $maxDaily) * 120); ?>px;" title="<?php echo e($day->total); ?>"></div>
                            <div class="bar-label"><?php echo e(\Carbon\Carbon::parse($day->production_date)->format('d')); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center text-muted w-100 py-4">No production data for this period</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-xl-4 col-lg-5 layout-spacing">
            <div class="widget-content widget-content-area br-8 h-100">
                <h6 class="mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-info me-2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                    Performance Summary
                </h6>

                <div class="mb-3 pb-3 border-bottom">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Working Days</span>
                        <strong><?php echo e($summary['working_days']); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Total Output</span>
                        <strong><?php echo e(number_format($summary['total_production'])); ?> pcs</strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Daily Average</span>
                        <strong><?php echo e(number_format($summary['avg_daily'])); ?> pcs</strong>
                    </div>
                </div>

                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">🟢 Green Lights</span>
                        <strong class="text-success"><?php echo e($summary['green_lights']); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">🔴 Red Alerts</span>
                        <strong class="text-danger"><?php echo e($summary['red_alerts']); ?></strong>
                    </div>
                </div>

                <?php if($summary['working_days'] > 0): ?>
                    <div class="text-center mt-4">
                        <div class="text-muted mb-1">Efficiency Score</div>
                        <div style="font-size: 2rem; font-weight: 700; color: <?php echo e($summary['red_alerts'] == 0 ? '#2ecc71' : ($summary['red_alerts'] < 5 ? '#f39c12' : '#e74c3c')); ?>;">
                            <?php echo e($summary['red_alerts'] == 0 ? '⭐ Excellent' : ($summary['red_alerts'] < 5 ? '👍 Good' : '⚠️ Needs Improvement')); ?>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="col-12 layout-spacing">
            <div class="widget-content widget-content-area br-8">
                <h6 class="mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-list me-2"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>
                    Recent Production Logs
                </h6>

                <?php $__empty_1 = true; $__currentLoopData = $recentLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="log-row d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center gap-3">
                            <span class="time"><?php echo e($log->production_hour); ?></span>
                            <span class="table-badge"><?php echo e($log->table->table_number); ?></span>
                            <span class="text-muted"><?php echo e($log->product_type ?? '-'); ?></span>
                        </div>
                        <div class="d-flex align-items-center gap-3">
                            <span class="text-muted"><?php echo e($log->production_date->format('M d, Y')); ?></span>
                            <span class="count badge" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff;">
                        <?php echo e($log->garments_count); ?> pcs
                    </span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-muted py-4">
                        No production logs found
                    </div>
                <?php endif; ?>

                
                <?php if($recentLogs->hasPages()): ?>
                    <div class="mt-4">
                        <?php echo e($recentLogs->appends(['start_date' => $startDate, 'end_date' => $endDate])->links('pagination::bootstrap-5')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kds\resources\views/reports/worker.blade.php ENDPATH**/ ?>