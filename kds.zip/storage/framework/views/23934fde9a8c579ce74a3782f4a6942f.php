<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('tables.index')); ?>">Tables</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo e($table->table_number); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row layout-top-spacing">
        
        <div class="col-xl-4 col-lg-5 col-md-12 col-sm-12 layout-spacing">
            <div class="widget-content widget-content-area br-8">
                <div class="text-center mb-4">
                    
                    <div class="qr-code-container mb-3" style="background: #fff; padding: 20px; border-radius: 10px; display: inline-block; border: 2px solid #e0e6ed;">
                        <?php echo QrCode::format('svg')->size(200)->errorCorrection('H')->generate($table->qr_code); ?>

                    </div>
                    <h4><?php echo e($table->table_number); ?></h4>
                    <p class="text-muted"><?php echo e($table->table_name); ?></p>

                    
                    <small class="text-muted d-block mb-2">
                        <code><?php echo e($table->qr_code); ?></code>
                    </small>
                </div>

                <div class="info-list">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Status:</span>
                        <?php if($table->is_active): ?>
                            <span class="badge badge-light-success">Active</span>
                        <?php else: ?>
                            <span class="badge badge-light-danger">Inactive</span>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Light Status:</span>
                        <?php if($table->current_light_status === 'red'): ?>
                            <span class="badge badge-danger">🔴 Red - Alert</span>
                        <?php elseif($table->current_light_status === 'green'): ?>
                            <span class="badge badge-success">🟢 Green - Good</span>
                        <?php elseif($table->current_light_status === 'blue'): ?>
                            <span class="badge badge-info">🔵 Blue - Help</span>
                        <?php else: ?>
                            <span class="badge badge-secondary">⚫ Off - Normal</span>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">ESP32 IP:</span>
                        <span><?php echo e($table->esp32_ip ?? 'Not configured'); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Device ID:</span>
                        <span><?php echo e($table->esp32_device_id ?? '-'); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Today's Production:</span>
                        <span class="badge badge-primary"><?php echo e($todayProduction); ?> pcs</span>
                    </div>
                </div>

                <hr>

                
                <h6>👤 Current Worker</h6>
                <?php if($table->currentAssignment?->worker): ?>
                    <div class="d-flex align-items-center p-2" style="background: #f8f9fa; border-radius: 8px;">
                        <div class="me-3">
                            <img src="<?php echo e($table->currentAssignment->worker->photo_url ?? asset('assets/src/assets/img/profile-30.png')); ?>"
                                 alt="<?php echo e($table->currentAssignment->worker->name); ?>"
                                 class="rounded-circle"
                                 width="50" height="50"
                                 style="object-fit: cover;">
                        </div>
                        <div>
                            <strong><?php echo e($table->currentAssignment->worker->name); ?></strong>
                            <br>
                            <small class="text-muted"><?php echo e($table->currentAssignment->worker->worker_id); ?></small>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-light-warning">
                        <small>No worker assigned today</small>
                    </div>
                <?php endif; ?>

                <hr>

                
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('tables.qr-download', $table)); ?>" class="btn btn-outline-secondary">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-download me-1"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                        Download QR Code (SVG)
                    </a>

                    <button onclick="window.print()" class="btn btn-outline-info">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-printer me-1"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                        Print QR Code
                    </button>

                    <?php if(auth()->user()->role === 'admin'): ?>
                        <a href="<?php echo e(route('tables.edit', $table)); ?>" class="btn btn-primary">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit me-1"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                            Edit Table
                        </a>

                        <form method="POST" action="<?php echo e(route('tables.regenerate-qr', $table)); ?>" onsubmit="return confirm('Regenerate QR code? The old QR will stop working.');">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-warning w-100">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-refresh-cw me-1"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
                                Regenerate QR Code
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-xl-8 col-lg-7 col-md-12 col-sm-12 layout-spacing">
            
            <div class="widget-content widget-content-area br-8 mb-4">
                <h5>📊 Hourly Production Today</h5>
                <canvas id="hourlyChart" height="200"></canvas>
            </div>

            
            <div class="widget-content widget-content-area br-8">
                <h5>📋 Recent Production Logs</h5>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Time</th>
                            <th>Worker</th>
                            <th>Garments</th>
                            <th>Product</th>
                            <th>Supervisor</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $table->productionLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($log->created_at->format('H:i')); ?></td>
                                <td><?php echo e($log->worker->name ?? '-'); ?></td>
                                <td><span class="badge badge-success"><?php echo e($log->garments_count); ?></span></td>
                                <td><?php echo e($log->product_type ?? '-'); ?></td>
                                <td><?php echo e($log->supervisor->name ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center">No production logs today</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
    <style>
        @media print {
            .sidebar-wrapper, .header-container, .footer-wrapper, .breadcrumb-style-one,
            .btn, button, form, .widget-content:not(:first-child) {
                display: none !important;
            }
            .qr-code-container {
                border: 3px solid #000 !important;
                padding: 30px !important;
            }
            .col-xl-4 {
                width: 100% !important;
                max-width: 400px !important;
                margin: 0 auto !important;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        // Hourly Production Chart
        const hourlyData = <?php echo json_encode($hourlyData, 15, 512) ?>;
        const hours = hourlyData.map(d => d.production_hour);
        const totals = hourlyData.map(d => d.total);

        new Chart(document.getElementById('hourlyChart'), {
            type: 'bar',
            data: {
                labels: hours.length ? hours : ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'],
                datasets: [{
                    label: 'Garments',
                    data: totals.length ? totals : [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                    backgroundColor: 'rgba(27, 85, 226, 0.7)',
                    borderColor: 'rgba(27, 85, 226, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\kds\resources\views/tables/show.blade.php ENDPATH**/ ?>