<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title><?php echo e(config('app.name', 'CNF')); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset("assets/src/assets/img/favicon-32x32.png")); ?>"/>
    <link href="<?php echo e(asset("assets/layouts/vertical-light-menu/css/light/loader.css")); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("assets/layouts/vertical-light-menu/css/dark/loader.css")); ?>" rel="stylesheet" type="text/css" />
    <script src="<?php echo e(asset("assets/layouts/vertical-light-menu/loader.js")); ?>"></script>

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <link href="<?php echo e(asset("assets/src/bootstrap/css/bootstrap.min.css")); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("assets/layouts/vertical-light-menu/css/light/plugins.css")); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("assets/layouts/vertical-light-menu/css/dark/plugins.css")); ?>" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->

    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
    <link href="<?php echo e(asset("assets/src/plugins/src/apex/apexcharts.css")); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset("assets/src/assets/css/light/dashboard/dash_1.css")); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("assets/src/assets/css/dark/dashboard/dash_1.css")); ?>" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("assets/src/plugins/src/tomSelect/tom-select.default.min.css")); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("assets/src/plugins/css/light/tomSelect/custom-tomSelect.css")); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("assets/src/plugins/css/dark/tomSelect/custom-tomSelect.css")); ?>">

    <!-- BEGIN THEME GLOBAL STYLES -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("assets/src/plugins/src/flatpickr/flatpickr.css")); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("assets/src/plugins/css/light/flatpickr/custom-flatpickr.css")); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("assets/src/plugins/css/dark/flatpickr/custom-flatpickr.css")); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <?php echo $__env->yieldContent('styles'); ?>

</head>
<body class="layout-boxed">
<!-- BEGIN LOADER -->
<?php echo $__env->make("layouts.partials.loader", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<?php echo $__env->make("layouts.partials.navbar", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!--  END NAVBAR  -->
<div class="main-container" id="container">

    <div class="overlay"></div>
    <div class="search-overlay"></div>

    <!--  BEGIN SIDEBAR  -->
    <?php echo $__env->make("layouts.partials.sidebar", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!--  END SIDEBAR  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">
            <div class="middle-content container-xxl p-0">

                <!--  BEGIN BREADCRUMBS  -->
            <?php echo $__env->make("layouts.partials.breadcrumbs", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <!--  END BREADCRUMBS  -->
            <?php echo $__env->yieldContent('content'); ?>

        </div>
        </div>
        <!--  BEGIN FOOTER  -->
        <?php echo $__env->make("layouts.partials.footer", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!--  END FOOTER  -->
    </div>
    <!--  END CONTENT AREA  -->

</div>
<!-- END MAIN CONTAINER -->

<!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
<!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
<script src="<?php echo e(asset("assets/src/plugins/src/global/vendors.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/src/bootstrap/js/bootstrap.bundle.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/src/plugins/src/perfect-scrollbar/perfect-scrollbar.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/src/plugins/src/mousetrap/mousetrap.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/src/plugins/src/waves/waves.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/layouts/vertical-light-menu/app.js")); ?>"></script>
<script src="<?php echo e(asset("assets/src/assets/js/custom.js")); ?>"></script>
<!-- END GLOBAL MANDATORY SCRIPTS -->

<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
<script src="<?php echo e(asset("assets/src/plugins/src/apex/apexcharts.min.js")); ?>"></script>
<script src="<?php echo e(asset("assets/src/assets/js/dashboard/dash_1.js")); ?>"></script>
<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->

<!-- BEGIN PAGE LEVEL SCRIPTS -->


<script src="<?php echo e(asset("assets/src/assets/js/scrollspyNav.js")); ?>"></script>
<script src="<?php echo e(asset("assets/src/plugins/src/tomSelect/tom-select.base.js")); ?>"></script>
<script src="<?php echo e(asset("assets/src/plugins/src/tomSelect/custom-tom-select.js")); ?>"></script>


<script src="<?php echo e(asset("assets/src/plugins/src/flatpickr/flatpickr.js")); ?>"></script>
<script src="<?php echo e(asset("assets/src/plugins/src/flatpickr/custom-flatpickr.js")); ?>"></script>


<!-- QR Scanner -->
<script src="https://unpkg.com/html5-qrcode"></script>

<!-- Chart.js for graphs -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Axios for API calls -->
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

<script>

    //Select Box
    new TomSelect("#select-beast",{
        create: true,
        sortField: {
            field: "text",
            direction: "asc"
        }
    });
    //Date Picker
    // var f1 = flatpickr(document.getElementById('basicFlatpickr'));
    var f1 = flatpickr(document.getElementById('basicFlatpickr'), {
        enableTime: true,
        dateFormat: "d-m-Y",
    });

</script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\kds\resources\views/layouts/layout.blade.php ENDPATH**/ ?>